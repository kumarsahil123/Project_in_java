/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;
/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2 
 */
/**
 *
 * @author Sahil Kumar
 *
 * Animal abstract class serves as a blueprint for all animals.
 */
public abstract class Animal implements Comparable<Animal>, Cloneable {
    private double weight;

    /**
     * Method to get the weight of the Animal.
     *
     * @return Weight as a double.
     */
    public double obtainWeight() {
        return this.weight;
    }

    /**
     * Method to set the weight of the Animal.
     *
     * @param weight - weight as a double.
     */
    public void assignWeight(double weight) {
        this.weight = weight;
    }

    /**
     * Method to compare the weight of two Animals.
     *
     * @param otherAnimal - Other Animal object to be compared with.
     * @return Result of the comparison.
     */
    public int compareTo(Animal otherAnimal) {
        return Double.compare(this.weight, otherAnimal.obtainWeight());
    }

    /**
     * Method to clone the Animal object.
     *
     * @return The cloned object.
     * @throws CloneNotSupportedException - Exception if cloning not supported.
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    /**
     * Abstract method to get the sound of the Animal.
     *
     * @return Sound as a String.
     */
    public abstract String makeSound();
}
