/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;
/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2 
 */
/**
 *
 * @author Sahil Kumar
 *
 * Chicken class extending Animal and implementing Edible.
 */
public class Chicken extends Animal implements Edible {
    /**
     * Method to get instructions on how to eat the Chicken.
     *
     * @return Instructions as a String.
     */
    public String howToEat() {
        return "Grill it";
    }

    /**
     * Method to get the sound of the Chicken.
     *
     * @return Sound as a String.
     */
    public String makeSound() {
        return "Cheep-cheep!";
    }
}
