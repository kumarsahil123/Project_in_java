/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;
/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2
 */
/**
 *
 * @author Sahil Kumar
 */
/**
 * Lion class extending Animal.
 */
public class Lion extends Animal {
    /**
     * Method to get the sound of the Lion.
     *
     * @return Sound as a String.
     */
    public String makeSound() {
        return "Roar!";
    }
}
