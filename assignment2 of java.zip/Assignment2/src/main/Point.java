/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;
/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2 
 */
/**
 *
 * @author Sahil Kumar
 */
 // Define the class Point which implements both Comparable and Cloneable interfaces
public class Point implements Comparable<Point>, Cloneable {
    // Declare private fields to represent a point (w, z)
    private double w;
    private double z;

    // Default constructor to initialize the point to (0, 0)
    public Point() {
        this.w = 0;
        this.z = 0;
    }

    // Parameterized constructor to initialize the point to given (w, z)
    public Point(double w, double z) {
        this.w = w;
        this.z = z;
    }

    // Getter method to fetch the w coordinate
    public double getW() {
        return this.w;
    }

    // Getter method to fetch the z coordinate
    public double getZ() {
        return this.z;
    }

    // Override equals method to check equality based on w and z values
    @Override
    public boolean equals(Object obj) {
        if (this == obj) // Same object reference
            return true;
        if (obj == null || getClass() != obj.getClass()) // Null or different class
            return false;
        Point other = (Point) obj; // Type cast to Point
        // Check if both w and z are equal
        return Double.compare(other.w, w) == 0 && Double.compare(other.z, z) == 0;
    }

    // Implement compareTo method to compare two points based on w and z values
    @Override
    public int compareTo(Point other) {
        // If w is greater return 1, if less return -1
        if (this.w != other.w)
            return this.w > other.w ? 1 : -1;
        // If w is equal, compare z
        return Double.compare(this.z, other.z);
    }

    // Override toString method to provide a custom string representation
    @Override
    public String toString() {
        return "[" + w + ", " + z + "]";
    }

    // Implement clone method to create and return a copy of this Point
    @Override
    public Point clone() {
        try {
            // Use super.clone() to leverage the clone method in Object class
            return (Point) super.clone();
        } catch (CloneNotSupportedException e) {
            // This shouldn't happen as we're Cloneable
            throw new AssertionError(); 
        }
    }
}

