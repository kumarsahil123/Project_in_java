/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;
/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2
 */
/**
 *
 * @author Sahil Kumar
 *
 * Fruit abstract class implements Edible interface.
 * It serves as a blueprint for all types of fruits.
 */
public abstract class Fruit implements Edible {
    // Currently empty, but can be extended as per requirement
}
