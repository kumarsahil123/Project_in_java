/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;

/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2 
 */
/**
 *
 * @author Sahil Kumar
 */
public class Ques02 {
    public static void main(String[] args) {
        // Instantiate two Point objects with different values
        Point p1 = new Point(3, 4);
        Point p2 = new Point(3.4, 1.4);

        // Test the equals method
        System.out.println(p1.equals(p2)); // false: not equal due to different w, z values
        System.out.println(p1.equals(p1)); // true: same instance

        // Test the compareTo method
        System.out.println(p1.compareTo(p2)); // -1: p1 is less than p2
        System.out.println(p2.compareTo(p1)); // 1: p2 is greater than p1

        // Test the clone method
        Point p3 = p1.clone();
        System.out.println(p3.equals(p1)); // true: p3 is a clone of p1
        System.out.println(p3); // [3.0, 4.0]: toString representation of the point
    }
}


