/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package main;
/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2
 */
/**
 *
 * @author Sahil Kumar
 */
public class Main {
    public static void main(String[] args) {
        // Array of Edible objects
        Edible[] edibles = new Edible[3];
        edibles[0] = new Chicken();
        edibles[1] = new Apple();
        edibles[2] = new Orange();

        // Loop through the array of Edible objects
        for (Edible edible : edibles) {
            System.out.println(edible.howToEat());
        }

        // Array of Animal objects
        Animal[] animals = new Animal[2];
        animals[0] = new Chicken();
        animals[1] = new Lion();

        // Loop through the array of Animal objects
        for (Animal animal : animals) {
            System.out.println(animal.makeSound());
        }
    }
}

