/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package main;
/*
    Name - Sahil Kumar
    Student id - 991699763
    Course - Prog24178
    Submitted to - Alaa Salih Mohammed
    Assignment2
 */
/**
 *
 * @author Sahil Kumar
 *
 * Orange class extends Fruit to provide instructions on how to eat an Orange.
 */
public class Orange extends Fruit {
    /**
     * Method to get instructions on how to eat an Orange.
     *
     * @return Instructions as a String.
     */
    public String howToEat() {
        return "Peel and eat";
    }
}
